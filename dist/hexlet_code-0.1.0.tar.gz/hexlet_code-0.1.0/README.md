### Hexlet tests and linter status:
[![Actions Status](https://github.com/Z4NDIE/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Z4NDIE/python-project-49/actions)
<a href="https://codeclimate.com/github/Z4NDIE/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2158d232f6f88c299670/maintainability" /></a>

# Проект "Игры разума".
## Представляет собой набор из пяти мини-игр: even, calculation, gcd, progression и prime. 
### Brain-even - проверяет число на четность.
### Brain-calc - калькулятор.
### Brain-gcd - находит наибольший общий делитель двух чисел.
### Brain-progression - арифметическая прогрессия.
### Brain-prime - проверяет число на простоту.

https://asciinema.org/a/619233 #brain-games
https://asciinema.org/a/619236 #brain-even
https://asciinema.org/a/619237 #brain-calc
https://asciinema.org/a/619238 #brain-gcd
https://asciinema.org/a/619239 #brain-progression
https://asciinema.org/a/619240 #brain-prime
