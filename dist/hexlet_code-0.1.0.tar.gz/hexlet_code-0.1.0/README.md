### Hexlet tests and linter status:
[![Actions Status](https://github.com/Z4NDIE/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Z4NDIE/python-project-49/actions)
<a href="https://codeclimate.com/github/Z4NDIE/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2158d232f6f88c299670/maintainability" /></a>
https://asciinema.org/a/618950 #brain-even
https://asciinema.org/a/618955 #brain-calc
https://asciinema.org/a/618960 #brain-gcd
https://asciinema.org/a/619064 #brain-progression
